package ch.fhnw.conpr.mandel;

public interface MandelbrotCalculator {
	int[] calculateMandelbrotIterations(int width, int height);
}
